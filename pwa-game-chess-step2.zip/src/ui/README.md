# UI components

Reusable React components (board, pieces, buttons, dialogs, etc.).
