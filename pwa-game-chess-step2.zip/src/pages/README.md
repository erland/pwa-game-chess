# Pages

Route-level pages (`HomePage`, `LocalSetupPage`, `GamePage`, etc.).
